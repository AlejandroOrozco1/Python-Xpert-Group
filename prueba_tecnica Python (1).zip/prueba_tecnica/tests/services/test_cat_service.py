import pytest
from unittest.mock import AsyncMock
from fastapi import HTTPException
import sys
import os
#solo uso para pruebas
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../')))

from app.services.cat_service import CatService
from app.schemas.cat_schema import CatBreedSchema


@pytest.fixture
def mock_cat_data():
    return [
        {
            "id": "abys",
            "name": "Abyssinian",
            "origin": "Egypt",
            "temperament": "Active, Energetic",
            "affection_level": 5,
            "child_friendly": 4,
            "dog_friendly": 4,
            "energy_level": 5,
            "hypoallergenic": 1
        }
    ]


@pytest.fixture
def mock_consumer(mock_cat_data):
    mock = AsyncMock()
    mock.get_breeds.return_value = mock_cat_data
    mock.get_breed_by_id.return_value = mock_cat_data[0]
    mock.search_breeds.return_value = mock_cat_data
    return mock


@pytest.mark.asyncio
async def test_get_all_breeds(mock_consumer, mock_cat_data):
    service = CatService(consumer=mock_consumer)
    breeds = await service.get_all_breeds()
    assert len(breeds) == 1
    assert isinstance(breeds[0], CatBreedSchema)
    assert breeds[0].name == mock_cat_data[0]["name"]


@pytest.mark.asyncio
async def test_get_breed_by_id(mock_consumer, mock_cat_data):
    service = CatService(consumer=mock_consumer)
    breed = await service.get_breed_by_id("abys")
    assert breed.name == mock_cat_data[0]["name"]


@pytest.mark.asyncio
async def test_get_breed_by_id_empty_list():
    mock = AsyncMock()
    mock.get_breed_by_id.return_value = []
    service = CatService(consumer=mock)
    with pytest.raises(HTTPException) as e:
        await service.get_breed_by_id("unknown")
    assert e.value.status_code == 404


@pytest.mark.asyncio
async def test_search_breeds(mock_consumer, mock_cat_data):
    service = CatService(consumer=mock_consumer)
    result = await service.search_breeds("Abyssinian")
    assert len(result) == 1
    assert result[0].name == "Abyssinian"


@pytest.mark.asyncio
async def test_search_breeds_advanced_found(mock_consumer):
    service = CatService(consumer=mock_consumer)
    results = await service.search_breeds_advanced(
        origin="Egypt",
        temperament="active",
        affection_level=4,
        dog_friendly=3,
        hypoallergenic=1
    )
    assert len(results) == 1
    assert results[0].origin == "Egypt"


@pytest.mark.asyncio
async def test_search_breeds_advanced_not_found(mock_consumer):
    mock_consumer.search_breeds.return_value = []
    service = CatService(consumer=mock_consumer)
    with pytest.raises(HTTPException) as e:
        await service.search_breeds_advanced(name="nonexistent")
    assert e.value.status_code == 404
