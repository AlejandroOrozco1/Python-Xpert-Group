import pytest
from unittest.mock import AsyncMock, patch
import sys
import os
#solo uso para pruebas
from uuid import uuid4
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../')))
from app.services.user_service import UserService
from app.schemas.user_schema import UserCreate, UserAuth ,UserOut
from app.models.user_model import User
from app.schemas.auth_schema import LoginResponse

@pytest.mark.asyncio
@patch("app.services.user_service.User")
@patch("app.services.user_service.get_password")
async def test_create_user_should_generate_unique_username(mock_get_password, mock_user_model):
    # Arrange
    mock_get_password.return_value = "hashed_pw"

    mock_user_instance = AsyncMock()
    mock_user_instance.username = "julio.orozco1"
    mock_user_instance.insert = AsyncMock()
    mock_user_model.return_value = mock_user_instance
    mock_user_model.by_username = AsyncMock(side_effect=[True, False])

    user_data = UserCreate(
        email="test@example.com",
        password="password123",
        first_name="Julio",
        last_name="Orozco"
    )

    # Act
    result = await UserService.create_user(user_data)

    # Assert
    assert result is not None
    assert "julio.orozco1" in result.username

@pytest.mark.asyncio
@patch("app.services.user_service.User")
@patch("app.services.user_service.verify_password")
async def test_authenticate_user_success(mock_verify_password, mock_user_model):
    # Arrange
    mock_user = AsyncMock()
    mock_user.hashed_password = "hashed"
    mock_user_model.by_username = AsyncMock(return_value=mock_user)
    mock_verify_password.return_value = True

    auth_data = UserAuth(username="julio.orozco", password="password123")

    # Act
    result = await UserService.authenticate_user(auth_data)

    # Assert
    assert result == mock_user

@pytest.mark.asyncio
@patch("app.services.user_service.create_access_token")
@patch("app.services.user_service.UserService.authenticate_user")
async def test_login_with_token_returns_token(mock_authenticate_user, mock_create_token):
    # Arrange
    # Usa un UserOut real, no un AsyncMock
    mock_user = UserOut(
        user_id=uuid4(),
        username="julio.orozco",
        email="test@example.com",
        first_name="Julio",
        last_name="Orozco",
        disable=False
    )
    mock_authenticate_user.return_value = mock_user
    mock_create_token.return_value = "fake.jwt.token"

    auth_data = UserAuth(username="julio.orozco", password="secret")

    # Act
    result = await UserService.login_with_token(auth_data)

    # Assert
    assert isinstance(result, LoginResponse)
    assert result.access_token == "fake.jwt.token"
    assert result.data == mock_user