from uuid import UUID
from pydantic import BaseModel 
from app.schemas.user_schema import UserOut

class TokenSchema(BaseModel):
    access_token: str
    refresh_token:str

class TokenPayload(BaseModel):
    sub: UUID = None
    exp: int = None

class LoginResponse(BaseModel):
    access_token: str
    data: UserOut