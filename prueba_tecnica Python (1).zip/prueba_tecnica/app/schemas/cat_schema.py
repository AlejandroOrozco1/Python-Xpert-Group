from pydantic import BaseModel, HttpUrl
from typing import Optional

class CatBreedSchema(BaseModel):
    id: str  
    name: str
    origin: Optional[str] = None
    description: Optional[str] = None
    temperament: Optional[str] = None
    life_span: Optional[str] = None
    wikipedia_url: Optional[HttpUrl] = None

    class Config:
        from_attributes = True
