from uuid import UUID
from pydantic import BaseModel, EmailStr, Field
from typing import Optional


class UserCreate(BaseModel):
    email: EmailStr = Field(..., description="Correo electrónico del usuario")
    password: str = Field(..., min_length=6, max_length=50, description="Contraseña del usuario")
    first_name: Optional[str] = Field(None, description="Nombre del usuario")
    last_name: Optional[str] = Field(None, description="Apellido del usuario")


class UserAuth(BaseModel):
    username: str = Field(..., min_length=4, max_length=50, description="Nombre de usuario")
    password: str = Field(..., min_length=6, max_length=50, description="Contraseña del usuario")


class UserOut(BaseModel):
    user_id: UUID
    username: str
    email: EmailStr
    first_name: Optional[str]
    last_name: Optional[str]
    disable: bool = False

    class Config:
        from_attributes = True
