from typing import List
from pydantic_settings import BaseSettings
from pydantic import AnyHttpUrl
from decouple import config

class Settings(BaseSettings):
    API_V1_STR: str = "/api/v1"

    # JWT
    JWT_SECRET_KEY: str = config("JWT_SECRET_KEY", cast=str)
    JWT_REFRESH_SECRET_KEY: str = config("JWT_REFRESH_SECRET_KEY", cast=str)
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 15
    REFRESH_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7

    # MongoDB
    MONGO_DB_CONNECTION: str = config("MONGO_DB_CONNECTION", cast=str)

    # CORS y proyecto
    BACKEND_CORS_ORIGINS: List[AnyHttpUrl] = []
    PROJECT_NAME: str = "Prueba Técnica - API de Gatos"

    # TheCatAPI
    CAT_API_BASE_URL: str = config("CAT_API_BASE_URL", cast=str)
    CAT_API_KEY: str = config("CAT_API_KEY", cast=str)

    class Config:
        case_sensitive = True

settings = Settings()
