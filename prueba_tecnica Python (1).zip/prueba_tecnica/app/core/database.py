from motor.motor_asyncio import AsyncIOMotorClient
from beanie import init_beanie
from app.models.user_model import User
from app.core.config import settings

db_client: AsyncIOMotorClient = None 

async def init_db():
    global db_client
    db_client = AsyncIOMotorClient(settings.MONGO_DB_CONNECTION)

    try:
        await db_client.server_info()
        print("Conexión a la base de datos exitosa.")
    except Exception as e:
        print(f"Error al conectar a la base de datos: {e}")
        raise e

    await init_beanie(
        database=db_client["ERP"],
        document_models=[
            User
        ]
    )
