from typing import List, Optional
from app.schemas.cat_schema import CatBreedSchema
from app.infrastructure.external_apis.cat_api_consumer import CatApiConsumer
from fastapi import HTTPException


class CatService:
    def __init__(self, consumer: CatApiConsumer = None):
        # Se usa el consumer de la API externa o se instancia uno nuevo
        self.consumer = consumer or CatApiConsumer()

    @staticmethod
    def _parse_cat_data(data: dict) -> CatBreedSchema:
        return CatBreedSchema.parse_obj(data)

    async def get_all_breeds(self) -> List[CatBreedSchema]:
        data = await self.consumer.get_breeds()
        return [self._parse_cat_data(item) for item in data]

    async def get_breed_by_id(self, breed_id: str) -> CatBreedSchema:
        data = await self.consumer.get_breed_by_id(breed_id)

       
        if isinstance(data, list):
            if not data:
                raise HTTPException(status_code=404, detail="Raza no encontrada.")
            data = data[0] 

        return self._parse_cat_data(data)

    async def search_breeds(self, query: str) -> List[CatBreedSchema]:
        
        data = await self.consumer.search_breeds(query)
        return [self._parse_cat_data(item) for item in data]

    async def search_breeds_advanced(
        self,
        name: Optional[str] = None,
        origin: Optional[str] = None,
        temperament: Optional[str] = None,
        affection_level: Optional[int] = None,
        child_friendly: Optional[int] = None,
        dog_friendly: Optional[int] = None,
        energy_level: Optional[int] = None,
        hypoallergenic: Optional[int] = None,
    ) -> List[CatBreedSchema]:
        data = await self.consumer.search_breeds(name or "")

        filtered = []
        for item in data:
            if origin and item.get("origin") != origin:
                continue
            if temperament and temperament.lower() not in item.get("temperament", "").lower():
                continue
            if affection_level and item.get("affection_level", 0) < affection_level:
                continue
            if child_friendly and item.get("child_friendly", 0) < child_friendly:
                continue
            if dog_friendly and item.get("dog_friendly", 0) < dog_friendly:
                continue
            if energy_level and item.get("energy_level", 0) < energy_level:
                continue
            if hypoallergenic is not None and item.get("hypoallergenic") != hypoallergenic:
                continue

            filtered.append(self._parse_cat_data(item))

        if not filtered:
            raise HTTPException(status_code=404, detail="No se encontraron razas que coincidan con los filtros.")

        return filtered
