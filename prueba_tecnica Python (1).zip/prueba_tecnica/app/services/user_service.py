from typing import List, Optional
from app.models.user_model import User
from app.schemas.user_schema import UserCreate, UserAuth
from app.schemas.auth_schema import LoginResponse
from app.core.security import get_password, verify_password, create_access_token
from fastapi import HTTPException, status


class UserService:

    @staticmethod
    async def get_all_users() -> List[User]:
        return await User.find_all().to_list()

    @staticmethod
    async def create_user(user_data: UserCreate) -> User:
        base_username = f"{user_data.first_name}.{user_data.last_name}".lower().replace(" ", "")
        username = base_username
        counter = 1

        while await User.by_username(username):
            username = f"{base_username}{counter}"
            counter += 1

        new_user = User(
            username=username,
            email=user_data.email,
            hashed_password=get_password(user_data.password),
            first_name=user_data.first_name,
            last_name=user_data.last_name
        )

        await new_user.insert()
        return new_user

    @staticmethod
    async def authenticate_user(auth_data: UserAuth) -> Optional[User]:
        user = await User.by_username(auth_data.username)
        if not user or not verify_password(auth_data.password, user.hashed_password):
            return None
        return user

    @staticmethod
    async def get_user_by_id(user_id: str) -> Optional[User]:
        return await User.find_one(User.user_id == user_id)

    @staticmethod
    async def login_with_token(auth_data: UserAuth) -> Optional[LoginResponse]:
        user = await UserService.authenticate_user(auth_data)
        if not user:
            return None

        token = create_access_token(str(user.user_id))
        return LoginResponse(
            access_token=token,
            data=user
        )
