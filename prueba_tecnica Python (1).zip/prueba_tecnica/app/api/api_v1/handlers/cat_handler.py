from fastapi import APIRouter, Depends, Query
from typing import List
from app.schemas.cat_schema import CatBreedSchema
from app.services.cat_service import CatService
from app.api.api_v1.depends.cat_deps import get_cat_service

cat_router = APIRouter(prefix="/cats", tags=["Gatos"])

@cat_router.get("/breeds", summary="Listar todas las razas de gatos", response_model=List[CatBreedSchema])
async def get_all_breeds(service: CatService = Depends(get_cat_service)):
    return await service.get_all_breeds()

@cat_router.get("/breeds/{breed_id}", summary="Obtener raza de gato por ID", response_model=CatBreedSchema)
async def get_breed_by_id(breed_id: str, service: CatService = Depends(get_cat_service)):
    return await service.get_breed_by_id(breed_id)

@cat_router.get("/breeds/search", summary="Buscar razas de gatos por nombre u otras características", response_model=List[CatBreedSchema])
async def search_breeds(
    name: str = Query(None, min_length=2),
    origin: str = Query(None),
    temperament: str = Query(None),
    affection_level: int = Query(None, ge=1, le=5),
    child_friendly: int = Query(None, ge=1, le=5),
    dog_friendly: int = Query(None, ge=1, le=5),
    energy_level: int = Query(None, ge=1, le=5),
    hypoallergenic: int = Query(None, ge=0, le=1),
    service: CatService = Depends(get_cat_service)
):
    return await service.search_breeds_advanced(
        name=name,
        origin=origin,
        temperament=temperament,
        affection_level=affection_level,
        child_friendly=child_friendly,
        dog_friendly=dog_friendly,
        energy_level=energy_level,
        hypoallergenic=hypoallergenic
    )

