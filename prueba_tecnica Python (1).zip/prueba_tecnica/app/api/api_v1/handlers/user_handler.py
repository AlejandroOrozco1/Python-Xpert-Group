from fastapi import APIRouter, HTTPException, status
from app.schemas.user_schema import UserCreate, UserOut, UserAuth
from app.schemas.auth_schema import LoginResponse
from app.services.user_service import UserService
from typing import List

router = APIRouter(prefix="/user", tags=["Usuarios"])

@router.get("/", response_model=List[UserOut], summary="Listar todos los usuarios")
async def list_users():
    users = await UserService.get_all_users()
    return users

@router.post("/", response_model=UserOut, summary="Crear un nuevo usuario")
async def create_user(user: UserCreate):
    try:
        new_user = await UserService.create_user(user)
        return new_user
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/login", response_model=LoginResponse, summary="Login de usuario")
async def login(auth_data: UserAuth):
    result = await UserService.login_with_token(auth_data)
    if not result:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Credenciales incorrectas"
        )
    return result