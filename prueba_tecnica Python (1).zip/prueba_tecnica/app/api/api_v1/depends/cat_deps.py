from app.services.cat_service import CatService
from app.infrastructure.external_apis.cat_api_consumer import CatApiConsumer

def get_cat_service() -> CatService:
    """
    Retorna una instancia del servicio de gatos con su consumer asociado.
    """
    consumer = CatApiConsumer()
    return CatService(consumer)
