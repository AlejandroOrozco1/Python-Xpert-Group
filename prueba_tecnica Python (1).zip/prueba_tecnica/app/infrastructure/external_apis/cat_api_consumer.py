import httpx
from fastapi import HTTPException
from app.core.config import settings

class CatApiConsumer:
    def __init__(self):
        self.base_url = settings.CAT_API_BASE_URL
        self.headers = {"x-api-key": settings.CAT_API_KEY}
        self.timeout = 10

    async def get_breeds(self):
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(f"{self.base_url}/breeds", headers=self.headers)
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as exc:
            raise HTTPException(status_code=exc.response.status_code, detail="Error al obtener las razas de gatos desde TheCatAPI.")
        except httpx.RequestError as exc:
            raise HTTPException(status_code=503, detail=f"Error de red al obtener las razas de gatos: {exc}")
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Error inesperado al obtener razas: {str(exc)}")

    async def get_breed_by_id(self, breed_id: str):
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(f"{self.base_url}/breeds/{breed_id}", headers=self.headers)
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as exc:
            raise HTTPException(status_code=exc.response.status_code, detail="Raza de gato no encontrada en TheCatAPI.")
        except httpx.RequestError as exc:
            raise HTTPException(status_code=503, detail=f"Error de red al consultar la raza de gato por ID: {exc}")
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Error inesperado al consultar raza por ID: {str(exc)}")

    async def search_breeds(self, query: str):
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(f"{self.base_url}/breeds/search?q={query}", headers=self.headers)
                response.raise_for_status()
                data = response.json()
                if not data:
                    raise HTTPException(status_code=404, detail="No se encontró ninguna raza con el término de búsqueda proporcionado.")
                return data
        except httpx.HTTPStatusError as exc:
            raise HTTPException(status_code=exc.response.status_code, detail="Error al buscar razas de gatos.")
        except httpx.RequestError as exc:
            raise HTTPException(status_code=503, detail=f"Error de red al buscar razas de gatos: {exc}")
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Error inesperado al buscar razas: {str(exc)}")
